;(function(root){
	root.wxChat = root.wxChat || {}

	//封装ajax
    wxChat.getData = function (options) {
        var defaults = {
                timeout : 10000,
                type: "post",
                dataType: "json",
                error : function(){
                    alert("网络错误请重试！");
                }
            },
            settings = $.extend({}, defaults, options);
        $.ajax(settings);
    }

	//主要数据源
	wxChat.dataSource = {
        chatMsg : {},
        memberCount : 0
	}

	wxChat.wxInit = new Vue({
		el : '#app',
		data : {
			wxData : wxChat.dataSource,
			test : wxChat.dataSource.memberCount,
			curMsg : ''
		},
		methods : {
            sendMsg : function () {

            	return;
                var that = this;
            	if(!that.curMsg) return alert('请输入内容！')
				wxChat.getData({
					url : 'http://test48.zuoyebang.cc/fdsaleteam/basic/sendmessage',
					data : {
                        toUid :123,
                        msgContent: that.curMsg
					},
					success : function (data) {
						console.log(data);
						that.curMsg = '';
                    },
					error : function () {
						console.log('connect failer');
                    }
				})
            }
		},
		events : {

		}
	});

	;(function(){

		wxChat.ws = (function(){
			return root.WebSocket;
		})();

		if(!wxChat.ws) return console.log('browser not support!');
		//else console.log('ok')

		//发送消息
		wxChat.sendMsg = function(){

		}
		//处理socket接收消息
		wxChat.msgHandler = new function () {
			let that = this;
			//获取好友列表
			that.group_user_list = function (data) {
				console.log(data);
			}

			//获取消息
			that.chat = function () {
				//是否是老师发出？
				let isTeacher;
				//塞入消息归类
				let pushID;
			}


		}

		//连接websocket
		;(function(){
			wxChat.args = arguments;
			wxChat.wxHost = 'ws://192.168.2.188:18686';
			if(!!wxChat.wxHost){
				console.log('连接失败，请刷新重试！')
				return;
			}

			//连接
			wxChat.socket = new wxChat.ws(wxChat.wxHost);

			//连接成功
			wxChat.socket.onopen = function (e) {
				console.log('WebSocket连接成功！');
			}

			//连接关闭
			wxChat.socket.onclose = function (e) {
				console.log('WebSocket连接关闭！');
			}

			//连接出错
			wxChat.socket.onerror = function (e) {
				console.log('WebSocket连接出错！');
			}

			//收发消息
			wxChat.socket.onmessage = function (e) {
				console.log(e);
				//let data = JSON.parse(e.data)
			}

		})();

	})();


})(window);

$(function () {
	$('.message-block').niceScroll({
        cursorcolor: "#424242",
        cursoropacitymin: 0,
        cursoropacitymax: .6,
        autohidemode: true,
        railpadding: { top: 10, right: -8, left: 0, bottom: 10 },
        hidecursordelay: 330
	});
	var lastMsg = $('.message-block')[0];
	if(!lastMsg) return;
    $('.message-block').scrollTop(lastMsg.scrollHeight);
})